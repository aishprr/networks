import sys
import math
import copy
import operator

UNBALANCED = -1
BALANCED = 1

finalNodeDict = dict()

def findAllTriads(nodeDict):
  
  triadInfo = dict()
  triadInfo[UNBALANCED] = []
  triadInfo[BALANCED] = []
  for node in nodeDict.keys():
    product = 1
    nodeInfo = nodeDict[node]
    for neigh in nodeInfo.keys():
      # go through each neighbour
      neighInfo = nodeDict[neigh]
      for neigh2 in neighInfo.keys():
        neigh2Info = nodeDict[neigh2]
        if node in neigh2Info.keys():
          # this is a triad
          product = nodeInfo[neigh] * neighInfo[neigh2] * neigh2Info[node]
          addToList = [node, neigh, neigh2]
          there = 0
          if (product < 0):
            for elem in triadInfo[UNBALANCED]:
              if set(elem) == set(addToList):
                there = 1
                break
            if not there:
              triadInfo[UNBALANCED] += [addToList]

            #print "UNBALANCED " + str(addToList) 
            #print nodeInfo
            #print neighInfo
            #print neigh2Info
          else:
            for elem in triadInfo[BALANCED]:
              if set(elem) == set(addToList):
                there = 1
                break
            if not there:
              triadInfo[BALANCED] += [addToList]
            #print "BALANCED " + str(addToList) 
            #print nodeInfo
            #print neighInfo
            #print neigh2Info

  return triadInfo

def recursivePropagate(nodeDict, edgeList, triads, A, B, changed, NodeIDMap):

  global finalNodeDict;
  nodeDict[A][B] = -nodeDict[A][B]
  nodeDict[B][A] = -nodeDict[B][A]


  for i in xrange(len(edgeList)):
    elem = edgeList[i]
    if (A in elem) and (B in elem): 
      edgeList[i][3] = -edgeList[i][3]

  triads = findAllTriads(nodeDict)
  balancedT = []
  unbalancedT = []
  T = []

  print A, B
  #print len(triads[BALANCED]), len(triads[UNBALANCED])

  for elem in triads[UNBALANCED]:
    if (A in elem) and (B in elem):
      unbalancedT += [elem]
      T += [elem]

  for elem in triads[BALANCED]:
    if (A in elem) and (B in elem):
      balancedT += [elem]
      T += [elem]

  #for t in balancedT: 
  #  if t in changed:
  #    continue
  #  changed += [t]

  # sort T in order of C
  toSortTupleList = []
  for t in T:
    C = t[2]
    toSortTupleList += [(t, NodeIDMap[C])]

  sortedT = zip(*sorted(toSortTupleList, key=lambda x: x[1]))[0]
  
  for t in sortedT: 
    if t in changed:
      continue
    if t in balancedT:
      changed += [t]
      continue
    found = False
    newA = t[0]
    newB = t[1]
    newC = t[2]
    toSortTupleListNow = [[(newA, newB), nodeDict[newA][newB]], 
                          [(newB, newC), nodeDict[newB][newC]], 
                          [(newA, newC), nodeDict[newA][newC]]]

    sortedComb = zip(*sorted(toSortTupleListNow, key=lambda x: x[1]))[0]
    ABCombFound = False
    BCCombFound = False
    ACCombFound = False
    for elem in changed:
      if (set(sortedComb[0]).issubset(set(elem))):
        ABCombFound = True
      elif (set(sortedComb[1]).issubset(set(elem))):
        BCCombFound = True
      elif (set(sortedComb[2]).issubset(set(elem))):
        ACCombFound = True
    if ABCombFound and BCCombFound and ACCombFound:
      continue
    else:
      if (not ABCombFound and not set(sortedComb[0]).issubset(set([A, B]))):
        edgeList = recursivePropagate(nodeDict, edgeList, triads, sortedComb[0][0], sortedComb[0][1], changed, NodeIDMap)
      elif (not BCCombFound and not set(sortedComb[1]).issubset(set([A, B]))):
        edgeList = recursivePropagate(nodeDict, edgeList, triads, sortedComb[1][0], sortedComb[1][1], changed, NodeIDMap)
      elif (not ACCombFound and not set(sortedComb[2]).issubset(set([A, B]))):
        edgeList = recursivePropagate(nodeDict, edgeList, triads, sortedComb[2][0], sortedComb[2][1], changed, NodeIDMap)

  finalNodeDict = nodeDict
  return edgeList

def main():
  global finalNodeDict

  try:
    with open("political_EdgeList.csv") as f1:
      edgeListLines = f1.readlines()
  except IOError:
    print("File does not exist")
    sys.exit()

  outFilename = sys.argv[1]
  A = sys.argv[2]
  B = sys.argv[3]

  lineCount = 0
  nodeDict = dict()
  edgeList = []
  for line in edgeListLines:
    if (lineCount == 0):
      lineCount += 1
      continue
    lineInfo = line.strip().rstrip().split(',')
    if lineInfo[0] not in nodeDict.keys():
      nodeDict[lineInfo[0]] = dict()
    if lineInfo[1] not in nodeDict.keys():
      nodeDict[lineInfo[1]] = dict()
    lineInfo[3] = int(lineInfo[3])
    nodeDict[lineInfo[0]][lineInfo[1]] = lineInfo[3]
    nodeDict[lineInfo[1]][lineInfo[0]] = lineInfo[3]
    edgeList += [lineInfo]
  #print edgeList
  #print nodeDict
  triadInfo = findAllTriads(nodeDict)
  #print triadInfo
  print "\n******************************************************************\n"
  print "Initially Unbalanced triads: " + str(len(triadInfo[UNBALANCED]))
  print "Initially Balanced triads: " + str(len(triadInfo[BALANCED]))
  print "\n******************************************************************\n"

  #A = 'israel'
  #B = 'islamic_state'
  changed = []
  nodeList = nodeDict.keys()
  nodeList.sort()
  print nodeList

  NodeIDMap = dict()

  for i in xrange(len(nodeList)):
    NodeIDMap[nodeList[i]] = i

  finalEdgeList = recursivePropagate(nodeDict, edgeList, triadInfo, A, B, changed, NodeIDMap)
  #print edgeList
  #print "*******************"
  #print finalEdgeList

  finalTriadInfo = findAllTriads(finalNodeDict)
  print "\n******************************************************************\n"
  print "Finally Unbalanced triads: " + str(len(finalTriadInfo[UNBALANCED]))
  print "Finally Balanced triads: " + str(len(finalTriadInfo[BALANCED]))
  print "\n******************************************************************\n"

  outF = open(outFilename, "w")
  strWrite = '%s,%s,%s,%s\n' % ('Source','Target','Type','Weight')
  outF.write(strWrite)
  for line in finalEdgeList:
    strWrite = '%s,%s,%s,%s\n' % (line[0], line[1], line[2], line[3])
    outF.write(strWrite)
  
if __name__ == "__main__":
  main()
