

for n = [4,5,6,7,8,9,10,11]
    randomSum = 0;
    stochSum = 0;
    destSumRandom = 0;
    destSumRandomCount = 0;
    destSumStoch = 0;
    destSumStochCount = 0;
    for i = 1:100
        [avgRandom, destRandom] = randomWalker2(n, 100, 5, 0.9, [1 1], [n n]);
        [avgStoch, destStoch] = stochasticComm2(n, 100, 0.3, 0, [1 1], [n n]);
        stochSum = stochSum + avgStoch;
        randomSum = randomSum + avgRandom;
        if (destStoch ~= -1)
            destSumStoch = destSumStoch + destStoch;
            destSumStochCount = destSumStochCount + 1;
        end
        if (destRandom ~= -1)
            destSumRandom = destSumRandom + destRandom;
            destSumRandomCount = destSumRandomCount + 1;
        end
    end
    fprintf('Random Walker N = %d OverallAvgHitTime = %f, DestAvgHitTime = %f\n', n, randomSum / 100, destSumRandom / destSumRandomCount);
    fprintf('Stochastic Communication N = %d OverallAvgHitTime = %f, DestAvgHitTime = %f\n', n, stochSum / 100, destSumStoch / destSumStochCount);
end

function [averageHitTime, destHitTime] = randomWalker2(N, T, kval, pFKRW, src, dest)
    % generate matrix N X N
    if (N < 1)
        return;
    end
    s = [];
    t = [];
    visitTime = -1 + zeros(N);
    visitTime(src(1), src(2)) = 0;
    visitedNodes = [];
    srcNodeID = (src(1)-1)*N + (src(2)-1) + 1;
    visitedNodes(end + 1) = srcNodeID;
    freqMatrix = zeros(N);
    freqMatrix(src(1), src(2)) = kval;
    total = N*N;
    for i = 1:total
        for k = 1:total
            c1 = rem((i-1), N) + 1;
            r1 = floor((i-1) / N) + 1; 
            c2 = rem((k-1), N) + 1;
            r2 = floor((k-1) / N) + 1;
            if (r1 == r2 && (abs(c1 - c2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
            if (c1 == c2 && (abs(r1 - r2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
        end
    end
    G = digraph(s,t);
    walkers = zeros(kval,2);
    for id = 1:kval
        walkers(id,1) = src(1);
        walkers(id,2) = src(2);
    end
    visitedNodeCount = [];
    visitedNodeCount(end + 1) = 1;
    for t = 1:T
        for id = 1:kval
            % go through each walker and move it around
            if (rand() < pFKRW)
                r = walkers(id, 1);
                c = walkers(id, 2);
                nodeID = (r-1)*N + (c-1) + 1;
                nodeNeighbours = successors(G, nodeID);
                msize = numel(nodeNeighbours);
                randIdxList = randperm(msize);
                newDest = nodeNeighbours(randIdxList(1));
                if (~ismember(newDest, visitedNodes))
                    visitedNodes(end+1) = newDest;
                    visitTime(rem((newDest-1), N) + 1, floor((newDest-1) / N) + 1) = t;
                end
                walkers(id, 1) = rem((newDest-1), N) + 1;
                walkers(id, 2) = floor((newDest-1) / N) + 1;
                freqMatrix(walkers(id, 1), walkers(id, 2)) = freqMatrix(walkers(id, 1), walkers(id, 2)) + 1;
                
            end
        end
        visitedNodeCount(end + 1) = numel(visitedNodes);
    end
    wrongSum = sum(sum(visitTime));
    minus1Count = sum(visitTime(:) == -1);
    actualSum = wrongSum + (minus1Count * -1);
    actualVis = numel(visitedNodes);
    averageHitTime = actualSum / actualVis;
    destHitTime = visitTime(dest(1), dest(2));
end

function [averageHitTime, destHitTime] = stochasticComm2(N, T, pfsc, pa, src, dest)
    % generate matrix N X N
    if (N < 1)
        return;
    end
    s = [];
    t = [];
    freqMatrix = zeros(N);
    freqMatrix(src(1), src(2)) = 1;
    total = N*N;
    for i = 1:total
        for k = 1:total
            c1 = rem((i-1), N) + 1;
            r1 = floor((i-1) / N) + 1; 
            c2 = rem((k-1), N) + 1;
            r2 = floor((k-1) / N) + 1;
            [i,k];
            [r1,c1,r2,c2];
            if (r1 == r2 && (abs(c1 - c2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
            if (c1 == c2 && (abs(r1 - r2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
        end
    end
    visitedNodes = [];
    srcNodeID = (src(1)-1)*N + (src(2)-1) + 1;
    visitedNodes(end + 1) = srcNodeID;
    visitedNodeCount = [];
    visitedNodeCount(end + 1) = 1;
    visitTime = -1 + zeros(N);
    visitTime(src(1), src(2)) = 0;
    G = digraph(s,t);
    spreaders = zeros(total, 2);
    spreadLength = 1;
    ignoreLength = 0;
    ignorers = zeros(total, 2);
    spreaders(1, 1) = src(1);
    spreaders(1, 2) = src(2);
    for t = 1:T
        if (spreadLength > 0)
            for k = 1:spreadLength
                if (rand() < pa && t > 1)
                    addedElems = 0;
                    for j = 1:spreadLength
                        found = 0;
                        for ig = 1:ignoreLength
                            if (eq(ignorers(ig, :), [neighR, neighC]))
                                found = 1;
                            end
                        end
                        if (found ~= 1)
                            addedElems = addedElems + 1;
                            ignorers(ignoreLength + j, 1) = spreaders(j, 1);
                            ignorers(ignoreLength + j, 2) = spreaders(j, 2);
                        end
                        
                    end
                    ignoreLength = ignoreLength + addedElems;
                    spreadLength = 0;
                end
                kthElemR = spreaders(k, 1);
                kthElemC = spreaders(k, 2);
                kthElemNodeID = (kthElemR-1)*N + (kthElemC-1) + 1;
                nodeNeighbours = successors(G, kthElemNodeID);
                for neighID = 1:numel(nodeNeighbours)
                    if (rand() < pfsc)
                        neigh = nodeNeighbours(neighID, 1);
                        neighR = floor((neigh-1) / N) + 1; 
                        neighC = rem((neigh-1), N) + 1;
                        found = 0;
                        for s = 1:spreadLength
                            if (eq(spreaders(s, :), [neighR, neighC]))
                                found = 1;
                            end
                        end
                        if (found ~= 1)
                            if (~ismember(neigh, visitedNodes))
                                visitedNodes(end+1) = neigh;
                                visitTime(neighR, neighC) = t;
                            end
                            spreaders(spreadLength + 1, 1) = neighR;
                            spreaders(spreadLength + 1, 2) = neighC;
                            freqMatrix(neighR, neighC) = freqMatrix(neighR, neighC) + 1;
                            spreadLength = spreadLength + 1;
                        end
                    end
                end
            end
        else
            break
        end
        visitedNodeCount(end + 1) = numel(visitedNodes);
    end
    wrongSum = sum(sum(visitTime));
    minus1Count = sum(visitTime(:) == -1);
    actualSum = wrongSum + (minus1Count * -1);
    actualVis = numel(visitedNodes);
    averageHitTime = actualSum / actualVis;
    destHitTime = visitTime(dest(1), dest(2));
end

