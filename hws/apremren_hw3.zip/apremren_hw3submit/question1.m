
randomWalker(20, 100, 5, 0.9, [1 1]);
% function stochasticComm(N, T, pfsc, pa, src)
stochasticComm(20, 100, 0.3, 0.002, [1 1]);
%stochasticComm(5, 5, 1, 1, [1 1]);

function randomWalker(N, T, kval, pFKRW, src)
    % generate matrix N X N
    if (N < 1)
        return;
    end
    s = [];
    t = [];
    visitedNodes = [];
    srcNodeID = (src(1)-1)*N + (src(2)-1) + 1;
    visitedNodes(end + 1) = srcNodeID;
    freqMatrix = zeros(N);
    freqMatrix(src(1), src(2)) = kval;
    total = N*N;
    for i = 1:total
        for k = 1:total
            c1 = rem((i-1), N) + 1;
            r1 = floor((i-1) / N) + 1; 
            c2 = rem((k-1), N) + 1;
            r2 = floor((k-1) / N) + 1;
            if (r1 == r2 && (abs(c1 - c2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
            if (c1 == c2 && (abs(r1 - r2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
        end
    end
    G = digraph(s,t);
    walkers = zeros(kval,2);
    for id = 1:kval
        walkers(id,1) = src(1);
        walkers(id,2) = src(2);
    end
    walkers
    visitedNodeCount = [];
    visitedNodeCount(end + 1) = 1;
    for t = 1:T
        for id = 1:kval
            % go through each walker and move it around
            if (rand() < pFKRW)
                r = walkers(id, 1);
                c = walkers(id, 2);
                nodeID = (r-1)*N + (c-1) + 1;
                nodeNeighbours = successors(G, nodeID);
                msize = numel(nodeNeighbours);
                randIdxList = randperm(msize);
                newDest = nodeNeighbours(randIdxList(1));
                if (~ismember(newDest, visitedNodes))
                    visitedNodes(end+1) = newDest
                end
                walkers(id, 1) = rem((newDest-1), N) + 1;
                walkers(id, 2) = floor((newDest-1) / N) + 1;
                freqMatrix(walkers(id, 1), walkers(id, 2)) = freqMatrix(walkers(id, 1), walkers(id, 2)) + 1;
            end
        end
        visitedNodeCount(end + 1) = numel(visitedNodes)
    end
    walkers
    visitedNodeCount
    figure(1);
    h = plot(G);
    figure(2);
    plot(1:numel(visitedNodeCount), visitedNodeCount, 'b');
    title('k = 5 Random Walk - Visited Node Count');
    xlabel('Number of Visited Nodes');
    ylabel('Time Units');
    
    figure(5)
    pcolor(freqMatrix)
    %colormap(gray(2))
    axis ij
    axis square
    title('k = 5 Random Walk - Node Visit Frequency Color Map');
    
end

function stochasticComm(N, T, pfsc, pa, src)
    % generate matrix N X N
    if (N < 1)
        return;
    end
    s = [];
    t = [];
    freqMatrix = zeros(N);
    freqMatrix(src(1), src(2)) = 1;
    total = N*N;
    for i = 1:total
        for k = 1:total
            c1 = rem((i-1), N) + 1;
            r1 = floor((i-1) / N) + 1; 
            c2 = rem((k-1), N) + 1;
            r2 = floor((k-1) / N) + 1;
            [i,k];
            [r1,c1,r2,c2];
            if (r1 == r2 && (abs(c1 - c2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
            if (c1 == c2 && (abs(r1 - r2) == 1))
                s(end + 1) = i;
                t(end + 1) = k;
            end
        end
    end
    visitedNodes = [];
    srcNodeID = (src(1)-1)*N + (src(2)-1) + 1;
    visitedNodes(end + 1) = srcNodeID;
    visitedNodeCount = [];
    visitedNodeCount(end + 1) = 1;
    
    G = digraph(s,t);
    spreaders = zeros(total, 2);
    spreadLength = 1;
    ignoreLength = 0;
    ignorers = zeros(total, 2);
    spreaders(1, 1) = src(1);
    spreaders(1, 2) = src(2);
    for t = 1:T
        if (spreadLength > 0)
            for k = 1:spreadLength
                if (rand() < pa && t > 1)
                    addedElems = 0;
                    for j = 1:spreadLength
                        found = 0;
                        for ig = 1:ignoreLength
                            if (eq(ignorers(ig, :), [neighR, neighC]))
                                found = 1;
                            end
                        end
                        if (found ~= 1)
                            addedElems = addedElems + 1;
                            ignorers(ignoreLength + j, 1) = spreaders(j, 1);
                            ignorers(ignoreLength + j, 2) = spreaders(j, 2);
                        end
                        
                    end
                    ignoreLength = ignoreLength + addedElems;
                    spreadLength = 0;
                end
                kthElemR = spreaders(k, 1);
                kthElemC = spreaders(k, 2);
                kthElemNodeID = (kthElemR-1)*N + (kthElemC-1) + 1;
                nodeNeighbours = successors(G, kthElemNodeID);
                for neighID = 1:numel(nodeNeighbours)
                    if (rand() < pfsc)
                        neigh = nodeNeighbours(neighID, 1);
                        neighR = floor((neigh-1) / N) + 1; 
                        neighC = rem((neigh-1), N) + 1;
                        found = 0;
                        for s = 1:spreadLength
                            if (eq(spreaders(s, :), [neighR, neighC]))
                                found = 1;
                            end
                        end
                        if (found ~= 1)
                            if (~ismember(neigh, visitedNodes))
                                visitedNodes(end+1) = neigh;
                            end
                            spreaders(spreadLength + 1, 1) = neighR;
                            spreaders(spreadLength + 1, 2) = neighC;
                            freqMatrix(neighR, neighC) = freqMatrix(neighR, neighC) + 1;
                            spreadLength = spreadLength + 1;
                        end
                    end
                end
            end
        else
            break
        end
        visitedNodeCount(end + 1) = numel(visitedNodes);
    end
    visitedNodeCount
    figure(4);
    plot(1:numel(visitedNodeCount), visitedNodeCount, 'r');
    title('Stochastic Communication - Visited Node Count - pa = 0.002');
    xlabel('Number of Visited Nodes');
    ylabel('Time Units');
    
    freqMatrix
    figure(6)
    pcolor(freqMatrix)
    %colormap(gray(2))
    axis ij
    axis square
    title('Stochastic Communication - Node Visit Frequency Color Map - pa = 0.002');
    
end

